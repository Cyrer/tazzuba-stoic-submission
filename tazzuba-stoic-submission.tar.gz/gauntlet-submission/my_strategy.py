"""Tazzuba Stoic — custom strategy for the NVIDIA Live Agent Gauntlet.

Philosophy: decide what matters (quality = 70% of score), drop what doesn't
(long rambles cost speed and tokens), and always leave an answer on the table
before the clock runs out.
"""

from __future__ import annotations

import re
from typing import Any

from base_strategy import BaseStrategy, ChallengeContext

# ---------------------------------------------------------------------------
# Model ranking heuristics. Rosters differ between Practice and the live event,
# so we score whatever aliases the proxy returns instead of hardcoding names.
# ---------------------------------------------------------------------------
_STRONG_HINTS = ("ultra", "super", "405b", "253b", "235b", "120b", "70b", "72b",
                 "large", "pro", "opus", "sonnet", "gpt-5", "gpt-4", "reason",
                 "r1", "thinking", "qwen3", "deepseek", "nemotron")
_FAST_HINTS = ("nano", "mini", "flash", "lite", "small", "haiku", "8b", "7b",
               "4b", "3b", "1b", "tiny")
_AVOID_FOR_TEXT = ("image", "vision-only", "embed", "rerank", "tts", "whisper",
                   "guard", "safety")


def _model_score(name: str, difficulty: str, time_left_s: float) -> float:
    n = name.lower()
    score = 0.0
    if any(h in n for h in _AVOID_FOR_TEXT):
        score -= 100
    strong = sum(1 for h in _STRONG_HINTS if h in n)
    fast = sum(1 for h in _FAST_HINTS if h in n)
    hard = difficulty.lower() in ("hard", "expert", "difficult", "very_hard")
    tight = 0 < time_left_s < 45
    # Quality dominates scoring, so lean strong — unless time is tight.
    score += strong * (4 if hard else 3)
    score -= fast * (3 if hard else 1)
    if tight:
        score += fast * 3
    # Bigger parameter counts usually reason better.
    m = re.search(r"(\d+)\s*b\b", n)
    if m:
        size = int(m.group(1))
        score += min(size, 300) / 60.0
    return score


class MyStrategy(BaseStrategy):
    """Tazzuba Stoic agent: careful reasoning, strict formatting, never late."""

    agent_id = "tazzuba-stoic"
    agent_name = "Tazzuba Stoic"

    text_system_prompt = (
        "You are a precise puzzle and reasoning solver competing in a timed arena.\n"
        "Method (do this silently, do not print it): restate what is asked, list "
        "every constraint from the rules and clues, solve step by step, then check "
        "your answer against EVERY constraint and the required output format.\n"
        "Output: the first line must be exactly 'ANSWER: <final answer>'. "
        "Match the requested format literally (case, separators, units, order, "
        "number of items). No extra words inside the answer.\n"
        "After the ANSWER line you may add at most one short justification line. "
        "Never output <think> tags. Never answer 'unknown' — give your best "
        "supported answer."
    )
    text_strategy_notes = (
        "Quality is 70% of the score: verify against constraints before answering. "
        "Brevity saves speed and tokens."
    )
    text_temperature = 0.0
    text_max_tokens = 8192

    image_strategy_notes = (
        "Edit when an input image exists, preserving everything not asked to change. "
        "Follow every constraint in the prompt literally. Standard resolution only."
    )

    # ---------------- model selection ----------------
    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        if self.is_image_challenge(ctx):
            preferred = self.prefer_image_models(available_models)
            if preferred:
                return preferred
            return list(available_models)
        indexed = list(enumerate(available_models))
        indexed.sort(
            key=lambda pair: (
                -_model_score(pair[1], ctx.difficulty, ctx.time_remaining_s),
                pair[0],  # stable: keep roster order on ties
            )
        )
        return [name for _, name in indexed]

    def pick_model(self, stage: str, ranked_models: list[str], ctx: ChallengeContext) -> str:
        if not ranked_models:
            return ""
        if stage == "fallback":
            # Watchdog emergency: the fastest usable text model wins.
            usable = [m for m in ranked_models if not any(h in m.lower() for h in _AVOID_FOR_TEXT)]
            pool = usable or ranked_models
            fast = [m for m in pool if any(h in m.lower() for h in _FAST_HINTS)]
            # ranked_models is strongest-first, so the last entry is the lightest.
            return fast[0] if fast else pool[-1]
        return ranked_models[0]

    # ---------------- prompting ----------------
    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        clues = [c.strip() for c in ctx.clues if c and c.strip()]
        clue_block = "\n".join(f"{i}. {c}" for i, c in enumerate(clues, 1)) or "(none)"
        parts = [
            f"CHALLENGE TYPE: {ctx.challenge_type.strip() or 'text'}",
            f"DIFFICULTY: {ctx.difficulty}",
        ]
        if ctx.challenge_text.strip() and ctx.challenge_text.strip() != ctx.description.strip():
            parts.append(f"TASK:\n{ctx.challenge_text.strip()}")
        parts.append(f"DESCRIPTION:\n{ctx.description.strip() or '(none)'}")
        parts.append(f"RULES (follow exactly, especially output format):\n{ctx.rules.strip() or '(none)'}")
        parts.append(f"CLUES:\n{clue_block}")
        parts.append(
            "Before answering, confirm silently that your answer satisfies every "
            "clue and the exact format in RULES.\n"
            "Respond now. First line: ANSWER: <final answer>"
        )
        return "\n\n".join(parts)

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        # Shrink the thinking budget when the clock is short so we still answer.
        max_tokens = self.text_max_tokens
        t = ctx.time_remaining_s
        if 0 < t < 30:
            max_tokens = 2048
        elif 0 < t < 60:
            max_tokens = 4096
        return {"temperature": float(self.text_temperature), "max_tokens": int(max_tokens)}

    # ---------------- timing ----------------
    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        # Speed is 15% of score: a clean answer should go in immediately.
        a = (answer or "").strip()
        return bool(a) and a.lower() not in ("unknown", "n/a", "none")

    def on_time_warning(self, remaining_s: float, current_answer: str, ctx: ChallengeContext) -> str | None:
        a = (current_answer or "").strip()
        if a and a.lower() not in ("unknown", "n/a"):
            return a
        # A wrong answer still beats no answer; use the first clue-shaped guess.
        return a or None

    # ---------------- images ----------------
    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        base = super().build_image_prompt(ctx)
        return (
            f"{base}\n\nFollow every instruction and constraint literally "
            "(e.g. 'no text' means no letters anywhere). If editing, keep the "
            "original composition, subjects and colours except what you were asked to change."
        )
